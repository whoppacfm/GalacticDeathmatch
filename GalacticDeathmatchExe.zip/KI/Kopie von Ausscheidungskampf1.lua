
addspeed()

if (getenemywinkel() > getwinkel() - 10) and (getenemywinkel() < getwinkel() + 10) and (getenemydif() < 500) then
  shoot()
end


if not haveweapon(3) then 
  goitem(3)
end


if haveitem(21) then
  if getenemydif() > 500 then
    useitem(21)
  end
else
  goitem(21)
end


for i = 0, 4, 1 do
  if haveweapon(i) then
    if (getweaponammo(i) > 0) or (getweaponammo(i) == -5) then
      setweapon(i)    
    end
  end 
end


if getenemydif() > 500 then
  goenemy()
else
  if not astaronline() then
    if getenemywinkel() > getwinkel() then
      goright()
    elseif getenemywinkel() < getwinkel() then
      goleft()
    end  
  end
end



