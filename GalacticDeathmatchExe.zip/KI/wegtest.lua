if getweaponrange() == 20 then
  shoot()
end